# Aula13RevisaoRecursaoTestes

# Teste 1

#include<stdio.h>
int main() {
    printf("\nOla mundo");

    main();
}

# Teste 2

#include<stdio.h>
void funcaoA(int i) {
    printf("\nOla mundo: %d", i);

    if (i < 10)
        funcaoA(i + 1);
}

int main() {
    int i = 1;
    funcaoA(i);

    return 0;
}

# Teste 3

#include<stdio.h>
void funcaoA(int n) {
    if(n > 0) {
        printf("\nOla mundo n: %d", n);
        funcaoA(n-2);
    }
}

int main() {
    funcaoA(10);

    return 0;
}

# Teste 4

#include<stdio.h>
void funcaoA(int n) {
    if(n > 0) {
        funcaoA(n-3);
        printf("\nola mundo n: %d", n);
    } else {
        return;
    }
}

int main() {
    funcaoA(10);

    return 0;
}
