#include<stdio.h>
#include<locale.h>
#include<time.h>

long long int fibonacci_it (int n) {
    long long int i = 0;
    long long int j = 1;
    long long int t, k;

    for (k = 1; k < n; k++) {
        t = i + j;
        i = j;
        j = t;
    }

    return j;
}

long long int fibonacci_rec(int i, int* count) {
    (*count)++;
    printf("\nfibonacci( %d ) - %d", i , *count);

    if(i == 0) { // caso base
        return 0;
    }

    if(i == 1) { // caso base
        return 1;
    } else {
        return fibonacci_rec(i-1, count) + fibonacci_rec(i-2, count);
    }
}

int main() {
    double tempo_rec, tempo_it;
    clock_t inicio, fim;
    int valor;

    int count = 0;

    setlocale(LC_ALL, ""); // caracteres com acentos no console

    printf("\n # Comparação entre Fibonacci iterativa e recursiva #\n");

    printf("\nDigite um número na sequência para ser encontrado/calculado: ");
    scanf("%d", &valor);
    printf("\nCalculando Fibonacci (%d)\n", valor);

    inicio = clock();
    printf("\n # Fibonacci iterativa: %lli", fibonacci_it(valor));
    fim = clock();

    tempo_it = ((double) (fim - inicio)) / CLOCKS_PER_SEC;
    printf("\n # Tempo na versão iterativa: %f", tempo_it);

    inicio = clock();
    printf("\n # Fibonacci recursiva: %lli", fibonacci_rec(valor, &count));
    fim = clock();

    tempo_rec = ((double) (fim - inicio)) / CLOCKS_PER_SEC;
    printf("\n # Tempo na versão recursiva: %f", tempo_rec);

    printf("\n # Versão iterativa é: %0.2fx mais rápida\n\n", tempo_rec/tempo_it);
    return 0;
}
